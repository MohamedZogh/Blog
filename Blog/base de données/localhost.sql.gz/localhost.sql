-- Adminer 4.7.1 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP DATABASE IF EXISTS `blog`;
CREATE DATABASE `blog` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `blog`;

DROP TABLE IF EXISTS `articles`;
CREATE TABLE `articles` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `articles` (`id`, `title`, `content`) VALUES
(1,	'Romain',	'Romain, un marseillais rêveur, a pour but de devenir le meilleur vendeur de sardines en France et il est prêt à tout pour y parvenir..'),
(2,	'Georges',	'Un géorgien quitte son pays dans l\'espoir d\'apprendre à coder...'),
(3,	'Harry Potter 3',	'azertyuio'),
(4,	'Harry potter 2 modif',	'azeyip'),
(5,	'Harry Potter 3',	'azeryuiop'),
(6,	'Harry Potter 3',	'azruyiop'),
(7,	'Harry Potter 3',	'azertyuiop'),
(8,	'Harry Potter 5',	'azeryuiop'),
(9,	'Eric',	'GRAND CUISINIER..... histoire');

DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_create` date NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `comments` (`id`, `date_create`, `content`) VALUES
(1,	'2019-02-20',	'Georges azertyuiop avec Romain azrtyuiopmlkjhfdsqwxcvbn,mlkjgfds42396215'),
(2,	'2019-02-21',	'Encore une fois, Romain galère un peu avec sa Vagrant. Mais il ne baisse pas les bras...'),
(4,	'2019-02-21',	'ssss'),
(5,	'2019-02-21',	'ssss'),
(6,	'2019-02-21',	'Psahtek la maguoille'),
(8,	'2019-02-21',	'azertyuiopmlkjhgfdsqwxcvbn'),
(9,	'2019-02-21',	'zertyuioAXELLLL8'),
(10,	'2019-02-21',	'zertyuizertyuioplkjhgfgoAXELLLL8'),
(11,	'2019-02-22',	'ok test 122.4'),
(12,	'2019-02-22',	'ertyui'),
(13,	'2019-02-22',	'efghjkl'),
(14,	'2019-02-22',	'BOnjour'),
(15,	'2019-02-22',	'Romain'),
(16,	'2019-02-22',	'Competences specifique\n'),
(17,	'2019-02-22',	'azertyuiokj'),
(18,	'2019-02-22',	'dfghjklm'),
(19,	'2019-02-22',	'ertyui'),
(20,	'2019-02-22',	'azertyuio'),
(21,	'2019-02-22',	'GEOOOOOOOORORORRRRRRRGGGGEEE'),
(22,	'2019-02-22',	'Psahtek Mourad');

DROP TABLE IF EXISTS `compteur`;
CREATE TABLE `compteur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `likes` int(11) NOT NULL,
  `dislikes` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `compteur` (`id`, `likes`, `dislikes`) VALUES
(1,	53,	45);

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `user` (`id`, `nom`, `prenom`, `email`) VALUES
(1,	'Sharmachvalexfili',	'Georges',	'Giorgio@hotmail.fr'),
(2,	'Paris',	'Romain',	'BgDuLaBonk@Vagrant.fr'),
(3,	'DURAND',	'iop',	'Maildutkt@hotmail.fr'),
(5,	'COIREXT',	'Bryan',	'bryan@coiret.com');

-- 2019-03-08 11:04:30
